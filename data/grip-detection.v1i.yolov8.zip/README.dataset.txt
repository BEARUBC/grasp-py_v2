# grip-detection > 2024-06-25 5:37am
https://universe.roboflow.com/grasp/grip-detection

Provided by a Roboflow user
License: CC BY 4.0

